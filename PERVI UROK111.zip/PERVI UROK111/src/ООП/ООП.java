package ООП;

public class ООП {
    public static void main(String[] args) {

    }
}
