package новаятема_23_10_23;

import java.util.Scanner;

public class Varargs {
    public static void main(String[] args) {


        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите слово: ");
        String word = scanner.nextLine();

        String result = processWord(word);
        System.out.println("Результат: " + result);
    }

    public static String processWord(String word) {
        word = word.toUpperCase();

        word = word.trim();

        int index = word.indexOf("А");
        if (index >= 0) {
            return word.substring(0, index + 1);
        } else {
            return "Слово не содержит";
        }
    }
}

//        String [] arr={"врач","стройшик","сваршик"};
//        for (String s :arr) {//цыкл фор эйч
//            System.out.println("мая професия "+s);
//        }


//    public static void someMethod(int... ff) {  // <-- метод Varargs
//        int y = 0;
//        for (int i = 0; i < ff.length; i++) {
//            y = y+ff[i];
//        }
//        System.out.println(y);
//    }


//   public static void someMethod(int u,int ... ff){  // <-- метод Varargs
//       for (int i = 0; i < ff.length; i++) {
//           ff[i]*=u;
//       }
//       System.out.println(Arrays.toString(ff));
//   }