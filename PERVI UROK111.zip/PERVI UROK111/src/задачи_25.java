package PACKAGE_NAME;public class задачи_25 {
}
